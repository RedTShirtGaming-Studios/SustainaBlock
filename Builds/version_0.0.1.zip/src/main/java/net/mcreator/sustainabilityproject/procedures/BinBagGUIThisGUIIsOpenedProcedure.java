package net.mcreator.sustainabilityproject.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;

import net.mcreator.sustainabilityproject.init.SustainabilityProjectModGameRules;

public class BinBagGUIThisGUIIsOpenedProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (world.getLevelData().getGameRules().getBoolean(SustainabilityProjectModGameRules.BINBAGRIPPING)) {
			itemstack.getOrCreateTag().putDouble("durability", (itemstack.getOrCreateTag().getDouble("durability") + 1));
			if (itemstack.getOrCreateTag()
					.getDouble("durability") == (world.getLevelData().getGameRules().getInt(SustainabilityProjectModGameRules.BINBAGUSES))) {
				BinBagDropItemsProcedure.execute(world, x, y, z, entity);
			}
		}
	}
}
