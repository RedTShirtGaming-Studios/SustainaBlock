
package net.mcreator.sustainabilityproject.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.sustainabilityproject.init.SustainabilityProjectModTabs;
import net.mcreator.sustainabilityproject.init.SustainabilityProjectModFluids;

public class PollutedWaterItem extends BucketItem {
	public PollutedWaterItem() {
		super(() -> SustainabilityProjectModFluids.POLLUTED_WATER, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1)
				.rarity(Rarity.COMMON).tab(SustainabilityProjectModTabs.TAB_BAD_THINGS));
		setRegistryName("polluted_water_bucket");
	}
}
