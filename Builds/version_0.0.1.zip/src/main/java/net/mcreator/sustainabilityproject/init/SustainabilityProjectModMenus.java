
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sustainabilityproject.init;

import net.minecraftforge.fmllegacy.network.IContainerFactory;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.AbstractContainerMenu;

import net.mcreator.sustainabilityproject.world.inventory.SmallPlasticSinkGUIMenu;
import net.mcreator.sustainabilityproject.world.inventory.RecyclerGUIMenu;
import net.mcreator.sustainabilityproject.world.inventory.CompactorGUIMenu;
import net.mcreator.sustainabilityproject.world.inventory.BinGUIMenu;
import net.mcreator.sustainabilityproject.world.inventory.BinBagGUIMenu;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class SustainabilityProjectModMenus {
	private static final List<MenuType<?>> REGISTRY = new ArrayList<>();
	public static final MenuType<BinBagGUIMenu> BIN_BAG_GUI = register("bin_bag_gui", (id, inv, extraData) -> new BinBagGUIMenu(id, inv, extraData));
	public static final MenuType<BinGUIMenu> BIN_GUI = register("bin_gui", (id, inv, extraData) -> new BinGUIMenu(id, inv, extraData));
	public static final MenuType<RecyclerGUIMenu> RECYCLER_GUI = register("recycler_gui",
			(id, inv, extraData) -> new RecyclerGUIMenu(id, inv, extraData));
	public static final MenuType<SmallPlasticSinkGUIMenu> SMALL_PLASTIC_SINK_GUI = register("small_plastic_sink_gui",
			(id, inv, extraData) -> new SmallPlasticSinkGUIMenu(id, inv, extraData));
	public static final MenuType<CompactorGUIMenu> COMPACTOR_GUI = register("compactor_gui",
			(id, inv, extraData) -> new CompactorGUIMenu(id, inv, extraData));

	private static <T extends AbstractContainerMenu> MenuType<T> register(String registryname, IContainerFactory<T> containerFactory) {
		MenuType<T> menuType = new MenuType<T>(containerFactory);
		menuType.setRegistryName(registryname);
		REGISTRY.add(menuType);
		return menuType;
	}

	@SubscribeEvent
	public static void registerContainers(RegistryEvent.Register<MenuType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new MenuType[0]));
	}
}
