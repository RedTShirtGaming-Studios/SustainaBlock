package net.mcreator.sustainabilityproject.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import java.util.Random;

public class PollutedWaterBlockAddedProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, BlockState blockstate) {
		while ((blockstate.getBlock().getStateDefinition().getProperty("pollutionLevel")instanceof IntegerProperty _ip
				? blockstate.getValue(_ip)
				: -1) == 0) {
			{
				int _value = new Random().nextInt(8 + 1);
				BlockPos _pos = new BlockPos((int) x, (int) y, (int) z);
				BlockState _bs = world.getBlockState(_pos);
				Property<?> _property = _bs.getBlock().getStateDefinition().getProperty("pollutionLevel");
				if (_property instanceof IntegerProperty _integerProp && _property.getPossibleValues().contains(_value))
					world.setBlock(_pos, _bs.setValue(_integerProp, _value), 3);
			}
		}
	}
}
