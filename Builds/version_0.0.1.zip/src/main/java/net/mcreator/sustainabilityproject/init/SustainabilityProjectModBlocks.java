
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sustainabilityproject.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.sustainabilityproject.block.SteelOreBlock;
import net.mcreator.sustainabilityproject.block.SteelBlockBlock;
import net.mcreator.sustainabilityproject.block.SolarPanelBlock;
import net.mcreator.sustainabilityproject.block.SmallPlasticSinkBlockBlock;
import net.mcreator.sustainabilityproject.block.ReinforcedConcreteBlock;
import net.mcreator.sustainabilityproject.block.RecyclerSideBlock;
import net.mcreator.sustainabilityproject.block.RecyclerInterfaceBlock;
import net.mcreator.sustainabilityproject.block.RecyclerBatteryBlock;
import net.mcreator.sustainabilityproject.block.PollutedWaterBlock;
import net.mcreator.sustainabilityproject.block.PackedWasteBlock;
import net.mcreator.sustainabilityproject.block.MultiblockIconBlock;
import net.mcreator.sustainabilityproject.block.MechanicalPistonBlock;
import net.mcreator.sustainabilityproject.block.GrinderBlock;
import net.mcreator.sustainabilityproject.block.CreativeBatteryBlock;
import net.mcreator.sustainabilityproject.block.CompactorInterfaceBlock;
import net.mcreator.sustainabilityproject.block.CompactorBatteryBlock;
import net.mcreator.sustainabilityproject.block.ComapctorSideBlock;
import net.mcreator.sustainabilityproject.block.BinBlock;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class SustainabilityProjectModBlocks {
	private static final List<Block> REGISTRY = new ArrayList<>();
	public static final Block BIN = register(new BinBlock());
	public static final Block REINFORCED_CONCRETE = register(new ReinforcedConcreteBlock());
	public static final Block STEEL_ORE = register(new SteelOreBlock());
	public static final Block STEEL_BLOCK = register(new SteelBlockBlock());
	public static final Block RECYCLER_SIDE = register(new RecyclerSideBlock());
	public static final Block RECYCLER_INTERFACE = register(new RecyclerInterfaceBlock());
	public static final Block SMALL_PLASTIC_SINK_BLOCK = register(new SmallPlasticSinkBlockBlock());
	public static final Block SOLAR_PANEL = register(new SolarPanelBlock());
	public static final Block POLLUTED_WATER = register(new PollutedWaterBlock());
	public static final Block MECHANICAL_PISTON = register(new MechanicalPistonBlock());
	public static final Block RECYCLER_BATTERY = register(new RecyclerBatteryBlock());
	public static final Block CREATIVE_BATTERY = register(new CreativeBatteryBlock());
	public static final Block GRINDER = register(new GrinderBlock());
	public static final Block COMPACTOR_INTERFACE = register(new CompactorInterfaceBlock());
	public static final Block COMPACTOR_SIDE = register(new ComapctorSideBlock());
	public static final Block COMPACTOR_BATTERY = register(new CompactorBatteryBlock());
	public static final Block PACKED_WASTE = register(new PackedWasteBlock());
	public static final Block MULTIBLOCK_ICON = register(new MultiblockIconBlock());

	private static Block register(Block block) {
		REGISTRY.add(block);
		return block;
	}

	@SubscribeEvent
	public static void registerBlocks(RegistryEvent.Register<Block> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Block[0]));
	}

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			BinBlock.registerRenderLayer();
			SmallPlasticSinkBlockBlock.registerRenderLayer();
			SolarPanelBlock.registerRenderLayer();
		}
	}
}
