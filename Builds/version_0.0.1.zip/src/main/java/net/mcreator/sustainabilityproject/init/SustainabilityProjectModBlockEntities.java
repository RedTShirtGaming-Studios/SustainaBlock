
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sustainabilityproject.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import net.mcreator.sustainabilityproject.block.entity.SolarPanelBlockEntity;
import net.mcreator.sustainabilityproject.block.entity.SmallPlasticSinkBlockBlockEntity;
import net.mcreator.sustainabilityproject.block.entity.RecyclerInterfaceBlockEntity;
import net.mcreator.sustainabilityproject.block.entity.RecyclerBatteryBlockEntity;
import net.mcreator.sustainabilityproject.block.entity.GrinderBlockEntity;
import net.mcreator.sustainabilityproject.block.entity.CreativeBatteryBlockEntity;
import net.mcreator.sustainabilityproject.block.entity.CompactorInterfaceBlockEntity;
import net.mcreator.sustainabilityproject.block.entity.BinBlockEntity;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class SustainabilityProjectModBlockEntities {
	private static final List<BlockEntityType<?>> REGISTRY = new ArrayList<>();
	public static final BlockEntityType<?> BIN = register("sustainability_project:bin", SustainabilityProjectModBlocks.BIN, BinBlockEntity::new);
	public static final BlockEntityType<?> RECYCLER_INTERFACE = register("sustainability_project:recycler_interface",
			SustainabilityProjectModBlocks.RECYCLER_INTERFACE, RecyclerInterfaceBlockEntity::new);
	public static final BlockEntityType<?> SMALL_PLASTIC_SINK_BLOCK = register("sustainability_project:small_plastic_sink_block",
			SustainabilityProjectModBlocks.SMALL_PLASTIC_SINK_BLOCK, SmallPlasticSinkBlockBlockEntity::new);
	public static final BlockEntityType<?> SOLAR_PANEL = register("sustainability_project:solar_panel", SustainabilityProjectModBlocks.SOLAR_PANEL,
			SolarPanelBlockEntity::new);
	public static final BlockEntityType<?> RECYCLER_BATTERY = register("sustainability_project:recycler_battery",
			SustainabilityProjectModBlocks.RECYCLER_BATTERY, RecyclerBatteryBlockEntity::new);
	public static final BlockEntityType<?> CREATIVE_BATTERY = register("sustainability_project:creative_battery",
			SustainabilityProjectModBlocks.CREATIVE_BATTERY, CreativeBatteryBlockEntity::new);
	public static final BlockEntityType<?> GRINDER = register("sustainability_project:grinder", SustainabilityProjectModBlocks.GRINDER,
			GrinderBlockEntity::new);
	public static final BlockEntityType<?> COMPACTOR_INTERFACE = register("sustainability_project:compactor_interface",
			SustainabilityProjectModBlocks.COMPACTOR_INTERFACE, CompactorInterfaceBlockEntity::new);

	private static BlockEntityType<?> register(String registryname, Block block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		BlockEntityType<?> blockEntityType = BlockEntityType.Builder.of(supplier, block).build(null).setRegistryName(registryname);
		REGISTRY.add(blockEntityType);
		return blockEntityType;
	}

	@SubscribeEvent
	public static void registerTileEntity(RegistryEvent.Register<BlockEntityType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new BlockEntityType[0]));
	}
}
