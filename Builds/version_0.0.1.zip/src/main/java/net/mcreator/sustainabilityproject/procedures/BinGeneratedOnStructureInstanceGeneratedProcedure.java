package net.mcreator.sustainabilityproject.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.sustainabilityproject.network.SustainabilityProjectModVariables;

public class BinGeneratedOnStructureInstanceGeneratedProcedure {
	public static void execute(LevelAccessor world) {
		SustainabilityProjectModVariables.MapVariables
				.get(world).GeneratedBins = SustainabilityProjectModVariables.MapVariables.get(world).GeneratedBins + 1;
		SustainabilityProjectModVariables.MapVariables.get(world).syncData(world);
	}
}
