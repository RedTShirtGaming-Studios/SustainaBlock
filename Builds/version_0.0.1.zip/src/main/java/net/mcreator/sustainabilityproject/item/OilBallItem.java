
package net.mcreator.sustainabilityproject.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.sustainabilityproject.init.SustainabilityProjectModTabs;

public class OilBallItem extends Item {
	public OilBallItem() {
		super(new Item.Properties().tab(SustainabilityProjectModTabs.TAB_ITEMS).stacksTo(64).rarity(Rarity.RARE));
		setRegistryName("oil_ball");
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
