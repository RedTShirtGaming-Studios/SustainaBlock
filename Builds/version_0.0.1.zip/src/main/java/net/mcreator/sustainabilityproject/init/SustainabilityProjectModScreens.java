
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sustainabilityproject.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import net.mcreator.sustainabilityproject.client.gui.SmallPlasticSinkGUIScreen;
import net.mcreator.sustainabilityproject.client.gui.RecyclerGUIScreen;
import net.mcreator.sustainabilityproject.client.gui.CompactorGUIScreen;
import net.mcreator.sustainabilityproject.client.gui.BinGUIScreen;
import net.mcreator.sustainabilityproject.client.gui.BinBagGUIScreen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class SustainabilityProjectModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(SustainabilityProjectModMenus.BIN_BAG_GUI, BinBagGUIScreen::new);
			MenuScreens.register(SustainabilityProjectModMenus.BIN_GUI, BinGUIScreen::new);
			MenuScreens.register(SustainabilityProjectModMenus.RECYCLER_GUI, RecyclerGUIScreen::new);
			MenuScreens.register(SustainabilityProjectModMenus.SMALL_PLASTIC_SINK_GUI, SmallPlasticSinkGUIScreen::new);
			MenuScreens.register(SustainabilityProjectModMenus.COMPACTOR_GUI, CompactorGUIScreen::new);
		});
	}
}
