
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sustainabilityproject.init;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.GameRules;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class SustainabilityProjectModGameRules {
	public static final GameRules.Key<GameRules.BooleanValue> BINBAGRIPPING = GameRules.register("binBagRipping", GameRules.Category.PLAYER,
			GameRules.BooleanValue.create(true));
	public static final GameRules.Key<GameRules.IntegerValue> BINBAGUSES = GameRules.register("binBagUses", GameRules.Category.MISC,
			GameRules.IntegerValue.create(3));
	public static final GameRules.Key<GameRules.IntegerValue> BINFILLUPRATE = GameRules.register("binFillupRate", GameRules.Category.UPDATES,
			GameRules.IntegerValue.create(10));
}
