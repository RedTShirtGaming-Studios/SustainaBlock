
package net.mcreator.sustainabilityproject.potion;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.sustainabilityproject.procedures.SicknessActiveTickConditionProcedure;

public class SicknessMobEffect extends MobEffect {
	public SicknessMobEffect() {
		super(MobEffectCategory.HARMFUL, -10066432);
		setRegistryName("sickness");
	}

	@Override
	public String getDescriptionId() {
		return "effect.sustainability_project.sickness";
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		Level world = entity.level;
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();

		SicknessActiveTickConditionProcedure.execute(entity);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
