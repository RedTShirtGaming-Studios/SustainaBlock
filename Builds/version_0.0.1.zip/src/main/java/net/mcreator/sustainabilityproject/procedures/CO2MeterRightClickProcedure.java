package net.mcreator.sustainabilityproject.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.TextComponent;

import net.mcreator.sustainabilityproject.network.SustainabilityProjectModVariables;

public class CO2MeterRightClickProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level.isClientSide())
			_player.displayClientMessage(new TextComponent((SustainabilityProjectModVariables.WorldVariables.get(world).CO2LEVEL + "/"
					+ SustainabilityProjectModVariables.WorldVariables.get(world).MAXCO2LEVEL)), (true));
	}
}
