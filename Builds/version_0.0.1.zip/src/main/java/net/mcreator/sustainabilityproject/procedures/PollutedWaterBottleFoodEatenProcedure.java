package net.mcreator.sustainabilityproject.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.sustainabilityproject.init.SustainabilityProjectModMobEffects;

public class PollutedWaterBottleFoodEatenProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _entity)
			_entity.addEffect(new MobEffectInstance(SustainabilityProjectModMobEffects.SICKNESS, 160, 2, (false), (true)));
	}
}
