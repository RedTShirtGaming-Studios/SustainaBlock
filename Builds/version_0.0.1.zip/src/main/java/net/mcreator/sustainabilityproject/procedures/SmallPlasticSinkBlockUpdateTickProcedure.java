package net.mcreator.sustainabilityproject.procedures;

import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.CapabilityItemHandler;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.BlockPos;

import net.mcreator.sustainabilityproject.network.SustainabilityProjectModVariables;
import net.mcreator.sustainabilityproject.init.SustainabilityProjectModItems;
import net.mcreator.sustainabilityproject.init.SustainabilityProjectModBlocks;

import java.util.concurrent.atomic.AtomicInteger;

public class SmallPlasticSinkBlockUpdateTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		boolean found = false;
		double sx = 0;
		double sy = 0;
		double sz = 0;
		double fx = 0;
		double fy = 0;
		double fz = 0;
		double wasteEffector = 0;
		sx = -3;
		found = false;
		for (int index0 = 0; index0 < (int) (6); index0++) {
			sy = -3;
			for (int index1 = 0; index1 < (int) (6); index1++) {
				sz = -3;
				for (int index2 = 0; index2 < (int) (6); index2++) {
					if ((world.getBlockState(new BlockPos((int) (x + sx), (int) (y + sy), (int) (z + sz))))
							.getBlock() == SustainabilityProjectModBlocks.POLLUTED_WATER) {
						found = true;
						fx = sx;
						fy = sy;
						fz = sz;
					}
					sz = sz + 1;
				}
				sy = sy + 1;
			}
			sx = sx + 1;
		}
		if (found == true) {
			{
				BlockPos _bp = new BlockPos((int) fx, (int) fy, (int) fz);
				BlockState _bs = Blocks.WATER.defaultBlockState();
				world.setBlock(_bp, _bs, 3);
			}
			if (new Object() {
				public int getAmount(LevelAccessor world, BlockPos pos, int sltid) {
					AtomicInteger _retval = new AtomicInteger(0);
					BlockEntity _ent = world.getBlockEntity(pos);
					if (_ent != null) {
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							_retval.set(capability.getStackInSlot(sltid).getCount());
						});
					}
					return _retval.get();
				}
			}.getAmount(world, new BlockPos((int) x, (int) y, (int) z), 0) > 64) {
				{
					BlockEntity _ent = world.getBlockEntity(new BlockPos((int) fx, (int) fy, (int) fz));
					if (_ent != null) {
						final int _sltid = 0;
						final ItemStack _setstack = new ItemStack(SustainabilityProjectModItems.PLASTIC_WASTE);
						_setstack.setCount((int) (new Object() {
							public double getValue(LevelAccessor world, BlockPos pos, String tag) {
								BlockEntity blockEntity = world.getBlockEntity(pos);
								if (blockEntity != null)
									return blockEntity.getTileData().getDouble(tag);
								return -1;
							}
						}.getValue(world, new BlockPos((int) fx, (int) fy, (int) fz), "pollutionLevel")));
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							if (capability instanceof IItemHandlerModifiable) {
								((IItemHandlerModifiable) capability).setStackInSlot(_sltid, _setstack);
							}
						});
					}
				}
				SustainabilityProjectModVariables.WorldVariables
						.get(world).CO2LEVEL = SustainabilityProjectModVariables.WorldVariables.get(world).CO2LEVEL + wasteEffector;
				SustainabilityProjectModVariables.WorldVariables.get(world).syncData(world);
			} else if (new Object() {
				public int getAmount(LevelAccessor world, BlockPos pos, int sltid) {
					AtomicInteger _retval = new AtomicInteger(0);
					BlockEntity _ent = world.getBlockEntity(pos);
					if (_ent != null) {
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							_retval.set(capability.getStackInSlot(sltid).getCount());
						});
					}
					return _retval.get();
				}
			}.getAmount(world, new BlockPos((int) x, (int) y, (int) z), 1) > 64) {
				{
					BlockEntity _ent = world.getBlockEntity(new BlockPos((int) fx, (int) fy, (int) fz));
					if (_ent != null) {
						final int _sltid = 1;
						final ItemStack _setstack = new ItemStack(SustainabilityProjectModItems.PLASTIC_WASTE);
						_setstack.setCount((int) (new Object() {
							public double getValue(LevelAccessor world, BlockPos pos, String tag) {
								BlockEntity blockEntity = world.getBlockEntity(pos);
								if (blockEntity != null)
									return blockEntity.getTileData().getDouble(tag);
								return -1;
							}
						}.getValue(world, new BlockPos((int) fx, (int) fy, (int) fz), "pollutionLevel")));
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							if (capability instanceof IItemHandlerModifiable) {
								((IItemHandlerModifiable) capability).setStackInSlot(_sltid, _setstack);
							}
						});
					}
				}
				SustainabilityProjectModVariables.WorldVariables
						.get(world).CO2LEVEL = SustainabilityProjectModVariables.WorldVariables.get(world).CO2LEVEL + wasteEffector;
				SustainabilityProjectModVariables.WorldVariables.get(world).syncData(world);
			} else if (new Object() {
				public int getAmount(LevelAccessor world, BlockPos pos, int sltid) {
					AtomicInteger _retval = new AtomicInteger(0);
					BlockEntity _ent = world.getBlockEntity(pos);
					if (_ent != null) {
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							_retval.set(capability.getStackInSlot(sltid).getCount());
						});
					}
					return _retval.get();
				}
			}.getAmount(world, new BlockPos((int) x, (int) y, (int) z), 2) > 64) {
				{
					BlockEntity _ent = world.getBlockEntity(new BlockPos((int) fx, (int) fy, (int) fz));
					if (_ent != null) {
						final int _sltid = 2;
						final ItemStack _setstack = new ItemStack(SustainabilityProjectModItems.PLASTIC_WASTE);
						_setstack.setCount((int) (new Object() {
							public double getValue(LevelAccessor world, BlockPos pos, String tag) {
								BlockEntity blockEntity = world.getBlockEntity(pos);
								if (blockEntity != null)
									return blockEntity.getTileData().getDouble(tag);
								return -1;
							}
						}.getValue(world, new BlockPos((int) fx, (int) fy, (int) fz), "pollutionLevel")));
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							if (capability instanceof IItemHandlerModifiable) {
								((IItemHandlerModifiable) capability).setStackInSlot(_sltid, _setstack);
							}
						});
					}
				}
				SustainabilityProjectModVariables.WorldVariables
						.get(world).CO2LEVEL = SustainabilityProjectModVariables.WorldVariables.get(world).CO2LEVEL + wasteEffector;
				SustainabilityProjectModVariables.WorldVariables.get(world).syncData(world);
			} else if (new Object() {
				public int getAmount(LevelAccessor world, BlockPos pos, int sltid) {
					AtomicInteger _retval = new AtomicInteger(0);
					BlockEntity _ent = world.getBlockEntity(pos);
					if (_ent != null) {
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							_retval.set(capability.getStackInSlot(sltid).getCount());
						});
					}
					return _retval.get();
				}
			}.getAmount(world, new BlockPos((int) x, (int) y, (int) z), 3) > 64) {
				{
					BlockEntity _ent = world.getBlockEntity(new BlockPos((int) fx, (int) fy, (int) fz));
					if (_ent != null) {
						final int _sltid = 3;
						final ItemStack _setstack = new ItemStack(SustainabilityProjectModItems.PLASTIC_WASTE);
						_setstack.setCount((int) (new Object() {
							public double getValue(LevelAccessor world, BlockPos pos, String tag) {
								BlockEntity blockEntity = world.getBlockEntity(pos);
								if (blockEntity != null)
									return blockEntity.getTileData().getDouble(tag);
								return -1;
							}
						}.getValue(world, new BlockPos((int) fx, (int) fy, (int) fz), "pollutionLevel")));
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							if (capability instanceof IItemHandlerModifiable) {
								((IItemHandlerModifiable) capability).setStackInSlot(_sltid, _setstack);
							}
						});
					}
				}
				SustainabilityProjectModVariables.WorldVariables
						.get(world).CO2LEVEL = SustainabilityProjectModVariables.WorldVariables.get(world).CO2LEVEL + wasteEffector;
				SustainabilityProjectModVariables.WorldVariables.get(world).syncData(world);
			} else if (new Object() {
				public int getAmount(LevelAccessor world, BlockPos pos, int sltid) {
					AtomicInteger _retval = new AtomicInteger(0);
					BlockEntity _ent = world.getBlockEntity(pos);
					if (_ent != null) {
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							_retval.set(capability.getStackInSlot(sltid).getCount());
						});
					}
					return _retval.get();
				}
			}.getAmount(world, new BlockPos((int) x, (int) y, (int) z), 4) > 64) {
				{
					BlockEntity _ent = world.getBlockEntity(new BlockPos((int) fx, (int) fy, (int) fz));
					if (_ent != null) {
						final int _sltid = 4;
						final ItemStack _setstack = new ItemStack(SustainabilityProjectModItems.PLASTIC_WASTE);
						_setstack.setCount((int) (new Object() {
							public double getValue(LevelAccessor world, BlockPos pos, String tag) {
								BlockEntity blockEntity = world.getBlockEntity(pos);
								if (blockEntity != null)
									return blockEntity.getTileData().getDouble(tag);
								return -1;
							}
						}.getValue(world, new BlockPos((int) fx, (int) fy, (int) fz), "pollutionLevel")));
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							if (capability instanceof IItemHandlerModifiable) {
								((IItemHandlerModifiable) capability).setStackInSlot(_sltid, _setstack);
							}
						});
					}
				}
				SustainabilityProjectModVariables.WorldVariables
						.get(world).CO2LEVEL = SustainabilityProjectModVariables.WorldVariables.get(world).CO2LEVEL + wasteEffector;
				SustainabilityProjectModVariables.WorldVariables.get(world).syncData(world);
			} else if (new Object() {
				public int getAmount(LevelAccessor world, BlockPos pos, int sltid) {
					AtomicInteger _retval = new AtomicInteger(0);
					BlockEntity _ent = world.getBlockEntity(pos);
					if (_ent != null) {
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							_retval.set(capability.getStackInSlot(sltid).getCount());
						});
					}
					return _retval.get();
				}
			}.getAmount(world, new BlockPos((int) x, (int) y, (int) z), 5) > 64) {
				{
					BlockEntity _ent = world.getBlockEntity(new BlockPos((int) fx, (int) fy, (int) fz));
					if (_ent != null) {
						final int _sltid = 5;
						final ItemStack _setstack = new ItemStack(SustainabilityProjectModItems.PLASTIC_WASTE);
						_setstack.setCount((int) (new Object() {
							public double getValue(LevelAccessor world, BlockPos pos, String tag) {
								BlockEntity blockEntity = world.getBlockEntity(pos);
								if (blockEntity != null)
									return blockEntity.getTileData().getDouble(tag);
								return -1;
							}
						}.getValue(world, new BlockPos((int) fx, (int) fy, (int) fz), "pollutionLevel")));
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							if (capability instanceof IItemHandlerModifiable) {
								((IItemHandlerModifiable) capability).setStackInSlot(_sltid, _setstack);
							}
						});
					}
				}
				SustainabilityProjectModVariables.WorldVariables
						.get(world).CO2LEVEL = SustainabilityProjectModVariables.WorldVariables.get(world).CO2LEVEL + wasteEffector;
				SustainabilityProjectModVariables.WorldVariables.get(world).syncData(world);
			} else if (new Object() {
				public int getAmount(LevelAccessor world, BlockPos pos, int sltid) {
					AtomicInteger _retval = new AtomicInteger(0);
					BlockEntity _ent = world.getBlockEntity(pos);
					if (_ent != null) {
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							_retval.set(capability.getStackInSlot(sltid).getCount());
						});
					}
					return _retval.get();
				}
			}.getAmount(world, new BlockPos((int) x, (int) y, (int) z), 6) > 64) {
				{
					BlockEntity _ent = world.getBlockEntity(new BlockPos((int) fx, (int) fy, (int) fz));
					if (_ent != null) {
						final int _sltid = 6;
						final ItemStack _setstack = new ItemStack(SustainabilityProjectModItems.PLASTIC_WASTE);
						_setstack.setCount((int) (new Object() {
							public double getValue(LevelAccessor world, BlockPos pos, String tag) {
								BlockEntity blockEntity = world.getBlockEntity(pos);
								if (blockEntity != null)
									return blockEntity.getTileData().getDouble(tag);
								return -1;
							}
						}.getValue(world, new BlockPos((int) fx, (int) fy, (int) fz), "pollutionLevel")));
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							if (capability instanceof IItemHandlerModifiable) {
								((IItemHandlerModifiable) capability).setStackInSlot(_sltid, _setstack);
							}
						});
					}
				}
				SustainabilityProjectModVariables.WorldVariables
						.get(world).CO2LEVEL = SustainabilityProjectModVariables.WorldVariables.get(world).CO2LEVEL + wasteEffector;
				SustainabilityProjectModVariables.WorldVariables.get(world).syncData(world);
			} else if (new Object() {
				public int getAmount(LevelAccessor world, BlockPos pos, int sltid) {
					AtomicInteger _retval = new AtomicInteger(0);
					BlockEntity _ent = world.getBlockEntity(pos);
					if (_ent != null) {
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							_retval.set(capability.getStackInSlot(sltid).getCount());
						});
					}
					return _retval.get();
				}
			}.getAmount(world, new BlockPos((int) x, (int) y, (int) z), 7) > 64) {
				{
					BlockEntity _ent = world.getBlockEntity(new BlockPos((int) fx, (int) fy, (int) fz));
					if (_ent != null) {
						final int _sltid = 7;
						final ItemStack _setstack = new ItemStack(SustainabilityProjectModItems.PLASTIC_WASTE);
						_setstack.setCount((int) (new Object() {
							public double getValue(LevelAccessor world, BlockPos pos, String tag) {
								BlockEntity blockEntity = world.getBlockEntity(pos);
								if (blockEntity != null)
									return blockEntity.getTileData().getDouble(tag);
								return -1;
							}
						}.getValue(world, new BlockPos((int) fx, (int) fy, (int) fz), "pollutionLevel")));
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							if (capability instanceof IItemHandlerModifiable) {
								((IItemHandlerModifiable) capability).setStackInSlot(_sltid, _setstack);
							}
						});
					}
				}
				SustainabilityProjectModVariables.WorldVariables
						.get(world).CO2LEVEL = SustainabilityProjectModVariables.WorldVariables.get(world).CO2LEVEL + wasteEffector;
				SustainabilityProjectModVariables.WorldVariables.get(world).syncData(world);
			} else if (new Object() {
				public int getAmount(LevelAccessor world, BlockPos pos, int sltid) {
					AtomicInteger _retval = new AtomicInteger(0);
					BlockEntity _ent = world.getBlockEntity(pos);
					if (_ent != null) {
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							_retval.set(capability.getStackInSlot(sltid).getCount());
						});
					}
					return _retval.get();
				}
			}.getAmount(world, new BlockPos((int) x, (int) y, (int) z), 8) > 64) {
				{
					BlockEntity _ent = world.getBlockEntity(new BlockPos((int) fx, (int) fy, (int) fz));
					if (_ent != null) {
						final int _sltid = 8;
						final ItemStack _setstack = new ItemStack(SustainabilityProjectModItems.PLASTIC_WASTE);
						_setstack.setCount((int) (new Object() {
							public double getValue(LevelAccessor world, BlockPos pos, String tag) {
								BlockEntity blockEntity = world.getBlockEntity(pos);
								if (blockEntity != null)
									return blockEntity.getTileData().getDouble(tag);
								return -1;
							}
						}.getValue(world, new BlockPos((int) fx, (int) fy, (int) fz), "pollutionLevel")));
						_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							if (capability instanceof IItemHandlerModifiable) {
								((IItemHandlerModifiable) capability).setStackInSlot(_sltid, _setstack);
							}
						});
					}
				}
				SustainabilityProjectModVariables.WorldVariables
						.get(world).CO2LEVEL = SustainabilityProjectModVariables.WorldVariables.get(world).CO2LEVEL + wasteEffector;
				SustainabilityProjectModVariables.WorldVariables.get(world).syncData(world);
			}
		}
	}
}
