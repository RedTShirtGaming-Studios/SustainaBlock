package net.mcreator.sustainabilityproject.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.world.SaplingGrowTreeEvent;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.sustainabilityproject.network.SustainabilityProjectModVariables;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class SaplingGrowProcedure {
	@SubscribeEvent
	public static void onSaplingGrow(SaplingGrowTreeEvent event) {
		execute(event, event.getWorld());
	}

	public static void execute(LevelAccessor world) {
		execute(null, world);
	}

	private static void execute(@Nullable Event event, LevelAccessor world) {
		SustainabilityProjectModVariables.WorldVariables.get(world).CO2LEVEL = SustainabilityProjectModVariables.WorldVariables.get(world).CO2LEVEL
				- 2;
		SustainabilityProjectModVariables.WorldVariables.get(world).syncData(world);
	}
}
