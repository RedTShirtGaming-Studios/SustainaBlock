package net.mcreator.sustainabilityproject.procedures;

import net.minecraftforge.fmllegacy.network.NetworkHooks;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.MenuProvider;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.sustainabilityproject.world.inventory.RecyclerGUIMenu;
import net.mcreator.sustainabilityproject.init.SustainabilityProjectModBlocks;

import io.netty.buffer.Unpooled;

public class RecyclerTestGUIProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		BlockState battery = Blocks.AIR.defaultBlockState();
		BlockState core = Blocks.AIR.defaultBlockState();
		BlockState frame = Blocks.AIR.defaultBlockState();
		battery = SustainabilityProjectModBlocks.RECYCLER_BATTERY.defaultBlockState();
		core = SustainabilityProjectModBlocks.GRINDER.defaultBlockState();
		frame = SustainabilityProjectModBlocks.RECYCLER_SIDE.defaultBlockState();
		if ((world.getBlockState(new BlockPos((int) x, (int) y, (int) (z - 1)))).getBlock() == (core).getBlock()
				&& (world.getBlockState(new BlockPos((int) x, (int) y, (int) (z - 2)))).getBlock() == (battery).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x + 1), (int) y, (int) z))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x - 1), (int) y, (int) z))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) z))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) x, (int) (y - 1), (int) z))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 1), (int) z))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) z))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) z))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 1), (int) z))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x + 1), (int) y, (int) (z - 1)))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x - 1), (int) y, (int) (z - 1)))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) x, (int) (y - 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x + 1), (int) y, (int) (z - 2)))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x - 1), (int) y, (int) (z - 2)))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) x, (int) (y - 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
				&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
				|| (world.getBlockState(new BlockPos((int) x, (int) y, (int) (z + 1)))).getBlock() == (core).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) y, (int) (z + 2)))).getBlock() == (battery).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) y, (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) y, (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y - 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) y, (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) y, (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y - 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) y, (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) y, (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y - 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
				|| (world.getBlockState(new BlockPos((int) (x - 1), (int) y, (int) z))).getBlock() == (core).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 2), (int) y, (int) z))).getBlock() == (battery).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) y, (int) (z + 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) y, (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y - 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) y, (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) y, (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y - 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) y, (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) y, (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y - 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
				|| (world.getBlockState(new BlockPos((int) (x + 1), (int) y, (int) z))).getBlock() == (core).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 2), (int) y, (int) z))).getBlock() == (battery).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) y, (int) (z + 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) y, (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y - 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 1), (int) z))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) y, (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) y, (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y - 1), (int) (z - 1)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) y, (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) y, (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) x, (int) (y - 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) (z - 2)))).getBlock() == (frame).getBlock()
						&& (world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 1), (int) (z - 2)))).getBlock() == (frame).getBlock()) {
			{
				if (entity instanceof ServerPlayer _ent) {
					BlockPos _bpos = new BlockPos((int) x, (int) y, (int) z);
					NetworkHooks.openGui((ServerPlayer) _ent, new MenuProvider() {
						@Override
						public Component getDisplayName() {
							return new TextComponent("RecyclerGUI");
						}

						@Override
						public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
							return new RecyclerGUIMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(_bpos));
						}
					}, _bpos);
				}
			}
		} else {
			if (entity instanceof Player _player)
				_player.closeContainer();
		}
	}
}
