package net.mcreator.sustainabilityproject.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.sustainabilityproject.network.SustainabilityProjectModVariables;

public class ReinforcedConcreteBlockAddedProcedure {
	public static void execute(LevelAccessor world) {
		SustainabilityProjectModVariables.WorldVariables.get(world).CO2LEVEL = SustainabilityProjectModVariables.WorldVariables.get(world).CO2LEVEL
				- 1;
		SustainabilityProjectModVariables.WorldVariables.get(world).syncData(world);
	}
}
