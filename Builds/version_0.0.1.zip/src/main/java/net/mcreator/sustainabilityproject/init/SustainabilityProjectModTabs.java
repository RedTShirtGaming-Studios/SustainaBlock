
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sustainabilityproject.init;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class SustainabilityProjectModTabs {
	public static CreativeModeTab TAB_BLOCKS;
	public static CreativeModeTab TAB_ITEMS;
	public static CreativeModeTab TAB_BAD_THINGS;

	public static void load() {
		TAB_BLOCKS = new CreativeModeTab("tabblocks") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(SustainabilityProjectModBlocks.REINFORCED_CONCRETE);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
		TAB_ITEMS = new CreativeModeTab("tabitems") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(SustainabilityProjectModItems.CO_2METER);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
		TAB_BAD_THINGS = new CreativeModeTab("tabbad_things") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(SustainabilityProjectModItems.BIN_BAG);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
