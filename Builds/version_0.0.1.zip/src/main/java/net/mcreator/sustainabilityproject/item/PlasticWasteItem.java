
package net.mcreator.sustainabilityproject.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.sustainabilityproject.init.SustainabilityProjectModTabs;

public class PlasticWasteItem extends Item {
	public PlasticWasteItem() {
		super(new Item.Properties().tab(SustainabilityProjectModTabs.TAB_BAD_THINGS).stacksTo(64).rarity(Rarity.COMMON));
		setRegistryName("plastic_waste");
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
