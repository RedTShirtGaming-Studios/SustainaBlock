
package net.mcreator.sustainabilityproject.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class BinBagRippedItem extends Item {
	public BinBagRippedItem() {
		super(new Item.Properties().tab(null).stacksTo(1).rarity(Rarity.COMMON));
		setRegistryName("bin_bag_ripped");
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
