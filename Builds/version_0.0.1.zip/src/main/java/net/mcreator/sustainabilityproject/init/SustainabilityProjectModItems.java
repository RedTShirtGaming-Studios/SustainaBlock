
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sustainabilityproject.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.sustainabilityproject.item.WikiBookItem;
import net.mcreator.sustainabilityproject.item.SteelRodItem;
import net.mcreator.sustainabilityproject.item.SteelNuggetItem;
import net.mcreator.sustainabilityproject.item.SteelIngotItem;
import net.mcreator.sustainabilityproject.item.ScreenItem;
import net.mcreator.sustainabilityproject.item.RebarItem;
import net.mcreator.sustainabilityproject.item.PollutedWaterItem;
import net.mcreator.sustainabilityproject.item.PollutedWaterBottleItem;
import net.mcreator.sustainabilityproject.item.PlasticWasteItem;
import net.mcreator.sustainabilityproject.item.OxygenGearItem;
import net.mcreator.sustainabilityproject.item.OilBallItem;
import net.mcreator.sustainabilityproject.item.MultimeterItem;
import net.mcreator.sustainabilityproject.item.Co2meterItem;
import net.mcreator.sustainabilityproject.item.BinBagRippedItem;
import net.mcreator.sustainabilityproject.item.BinBagItem;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class SustainabilityProjectModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item CO_2METER = register(new Co2meterItem());
	public static final Item BIN = register(SustainabilityProjectModBlocks.BIN, SustainabilityProjectModTabs.TAB_BAD_THINGS);
	public static final Item BIN_BAG = register(new BinBagItem());
	public static final Item REINFORCED_CONCRETE = register(SustainabilityProjectModBlocks.REINFORCED_CONCRETE,
			SustainabilityProjectModTabs.TAB_BLOCKS);
	public static final Item STEEL_INGOT = register(new SteelIngotItem());
	public static final Item STEEL_ORE = register(SustainabilityProjectModBlocks.STEEL_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item STEEL_BLOCK = register(SustainabilityProjectModBlocks.STEEL_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item REBAR = register(new RebarItem());
	public static final Item RECYCLER_SIDE = register(SustainabilityProjectModBlocks.RECYCLER_SIDE, SustainabilityProjectModTabs.TAB_BLOCKS);
	public static final Item RECYCLER_INTERFACE = register(SustainabilityProjectModBlocks.RECYCLER_INTERFACE,
			SustainabilityProjectModTabs.TAB_BLOCKS);
	public static final Item SMALL_PLASTIC_SINK_BLOCK = register(SustainabilityProjectModBlocks.SMALL_PLASTIC_SINK_BLOCK,
			SustainabilityProjectModTabs.TAB_BLOCKS);
	public static final Item SOLAR_PANEL = register(SustainabilityProjectModBlocks.SOLAR_PANEL, SustainabilityProjectModTabs.TAB_BLOCKS);
	public static final Item MULTIMETER = register(new MultimeterItem());
	public static final Item BIN_BAG_RIPPED = register(new BinBagRippedItem());
	public static final Item POLLUTED_WATER_BUCKET = register(new PollutedWaterItem());
	public static final Item PLASTIC_WASTE = register(new PlasticWasteItem());
	public static final Item OIL_BALL = register(new OilBallItem());
	public static final Item MECHANICAL_PISTON = register(SustainabilityProjectModBlocks.MECHANICAL_PISTON, SustainabilityProjectModTabs.TAB_BLOCKS);
	public static final Item RECYCLER_BATTERY = register(SustainabilityProjectModBlocks.RECYCLER_BATTERY, SustainabilityProjectModTabs.TAB_BLOCKS);
	public static final Item CREATIVE_BATTERY = register(SustainabilityProjectModBlocks.CREATIVE_BATTERY, SustainabilityProjectModTabs.TAB_BLOCKS);
	public static final Item GRINDER = register(SustainabilityProjectModBlocks.GRINDER, SustainabilityProjectModTabs.TAB_BLOCKS);
	public static final Item POLLUTED_WATER_BOTTLE = register(new PollutedWaterBottleItem());
	public static final Item OXYGEN_GEAR_HELMET = register(new OxygenGearItem.Helmet());
	public static final Item OXYGEN_GEAR_CHESTPLATE = register(new OxygenGearItem.Chestplate());
	public static final Item STEEL_NUGGET = register(new SteelNuggetItem());
	public static final Item WIKI_BOOK = register(new WikiBookItem());
	public static final Item COMPACTOR_INTERFACE = register(SustainabilityProjectModBlocks.COMPACTOR_INTERFACE,
			SustainabilityProjectModTabs.TAB_BLOCKS);
	public static final Item COMPACTOR_SIDE = register(SustainabilityProjectModBlocks.COMPACTOR_SIDE, SustainabilityProjectModTabs.TAB_BLOCKS);
	public static final Item COMPACTOR_BATTERY = register(SustainabilityProjectModBlocks.COMPACTOR_BATTERY, SustainabilityProjectModTabs.TAB_BLOCKS);
	public static final Item PACKED_WASTE = register(SustainabilityProjectModBlocks.PACKED_WASTE, SustainabilityProjectModTabs.TAB_BLOCKS);
	public static final Item MULTIBLOCK_ICON = register(SustainabilityProjectModBlocks.MULTIBLOCK_ICON, null);
	public static final Item STEEL_ROD = register(new SteelRodItem());
	public static final Item SCREEN = register(new ScreenItem());

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	private static Item register(Block block, CreativeModeTab tab) {
		return register(new BlockItem(block, new Item.Properties().tab(tab)).setRegistryName(block.getRegistryName()));
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}
